#ifndef MERGESORT_H
#define MERGESORT_H

//
// mergesort.c
//
// MIT licensed.
// Copyright (c) Abraham Hernandez <abraham@abranhe.com>
//

#ifdef __cplusplus
extern "C" {
#endif

void
mergeSort(int arr[], int l, int r);

#ifdef __cplusplus
}
#endif

#endif // MERGESORT_H
